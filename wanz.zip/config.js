module.exports = {
  BOT_TOKEN: "7800867804:AAEZf8rfldRA8huA355Uy11hAMU00j2_FqA",
  OWNER_ID: ["7774371395"],
};
//@putra_444