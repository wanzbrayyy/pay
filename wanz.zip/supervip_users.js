const supervipUsers = [

  { id: '7774371395', expiry: 1684022400000 }, 
  
];

module.exports = supervipUsers;
